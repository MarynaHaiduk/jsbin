webpackJsonp([1],[
/* 0 */,
/* 1 */
/***/ function(module, exports) {

	'use strict';

	module.exports = function() {
	  alert("login");
	};




/***/ },
/* 2 */
/***/ function(module, exports) {

	'use strict';

	module.exports = function() {
	  alert("logout");
	};




/***/ }
]);