'use strict';

module.exports = function() {
  alert("login");
};


