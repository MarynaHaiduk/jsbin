/**
 * Polyfills
 * Basic functions
 * Other common stuff
 */
