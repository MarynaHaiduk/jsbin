'use strict';

let old = require('old');

old();