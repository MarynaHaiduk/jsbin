var about =
webpackJsonp_name_([0],[
/* 0 */
/***/ function(module, exports, __webpack_require__) {

	'use strict';

	var _interopRequireDefault = __webpack_require__(1)['default'];

	var _welcome = __webpack_require__(2);

	var _welcome2 = _interopRequireDefault(_welcome);

	(0, _welcome2['default'])("about");

	exports.welcome = _welcome2['default'];

/***/ }
]);
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYWJvdXQuanMiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8vLi9hYm91dC5qcyJdLCJzb3VyY2VzQ29udGVudCI6WyIndXNlIHN0cmljdCc7XG5cbmltcG9ydCB3ZWxjb21lIGZyb20gJy4vd2VsY29tZSc7XG5cbndlbGNvbWUoXCJhYm91dFwiKTtcblxuZXhwb3J0cy53ZWxjb21lID0gd2VsY29tZTtcblxuXG5cblxuLyoqIFdFQlBBQ0sgRk9PVEVSICoqXG4gKiogLi9hYm91dC5qc1xuICoqLyJdLCJtYXBwaW5ncyI6Ijs7Ozs7QUFBQTtBQUNBOzs7QUFDQTtBQUNBOzs7QUFDQTtBQUNBOzs7OyIsInNvdXJjZVJvb3QiOiIifQ==