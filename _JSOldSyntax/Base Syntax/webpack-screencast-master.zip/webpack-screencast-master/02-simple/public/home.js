var home =
webpackJsonp_name_([2],[
/* 0 */
/***/ function(module, exports, __webpack_require__) {

	'use strict';

	var _interopRequireDefault = __webpack_require__(1)['default'];

	var _welcome = __webpack_require__(2);

	var _welcome2 = _interopRequireDefault(_welcome);

	(0, _welcome2['default'])("home");

	exports.welcome = _welcome2['default'];

/***/ }
]);
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaG9tZS5qcyIsInNvdXJjZXMiOlsid2VicGFjazovLy8uL2hvbWUuanMiXSwic291cmNlc0NvbnRlbnQiOlsiJ3VzZSBzdHJpY3QnO1xuXG5pbXBvcnQgd2VsY29tZSBmcm9tICcuL3dlbGNvbWUnO1xuXG53ZWxjb21lKFwiaG9tZVwiKTtcblxuZXhwb3J0cy53ZWxjb21lID0gd2VsY29tZTtcblxuXG5cblxuLyoqIFdFQlBBQ0sgRk9PVEVSICoqXG4gKiogLi9ob21lLmpzXG4gKiovIl0sIm1hcHBpbmdzIjoiOzs7OztBQUFBO0FBQ0E7OztBQUNBO0FBQ0E7OztBQUNBO0FBQ0E7Ozs7Iiwic291cmNlUm9vdCI6IiJ9