'use strict';

import welcome from './welcome';

welcome("about");

exports.welcome = welcome;

