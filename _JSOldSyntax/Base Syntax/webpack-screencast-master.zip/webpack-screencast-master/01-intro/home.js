'use strict';

import welcome from './welcome';

welcome("home");

exports.welcome = welcome;

