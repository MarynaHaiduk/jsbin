"use strict";

import angular from 'angular';