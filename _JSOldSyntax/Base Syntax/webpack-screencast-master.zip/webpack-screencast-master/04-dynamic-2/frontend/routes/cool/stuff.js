"use strict";

module.exports = function() {
  alert("cool stuff");
};