'use strict';

module.exports = function() {
  alert('home');
};