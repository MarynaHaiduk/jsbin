webpackJsonp([1],{

/***/ 3:
/***/ function(module, exports) {

	'use strict';

	module.exports = function() {
	  alert('about');
	};

/***/ }

});