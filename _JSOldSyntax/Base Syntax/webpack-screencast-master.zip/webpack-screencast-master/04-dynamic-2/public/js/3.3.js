webpackJsonp([3],{

/***/ 7:
/***/ function(module, exports) {

	'use strict';

	module.exports = function() {
	  alert('home');
	};

/***/ }

});