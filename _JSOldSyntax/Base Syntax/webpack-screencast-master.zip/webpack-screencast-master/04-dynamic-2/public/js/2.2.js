webpackJsonp([2],{

/***/ 5:
/***/ function(module, exports) {

	"use strict";

	module.exports = function() {
	  alert("cool stuff");
	};

/***/ }

});